# risk_of_multiprinting
Risk of Rain 2 mod that allows printing of multiple items

Interacting with 3D printers pops up a slider UI to select up to 50 items to be printed simultanously. 

README improvements coming soon... 
